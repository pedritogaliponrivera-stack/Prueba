# ecomiga · Catálogo web

Sitio estático del catálogo de yogurt griego ecomiga. **1 home + 7 páginas de sabor** + **WhatsApp flotante** en todas.

---

## 📁 Estructura

```
ecomiga-site/
├── index.html                  ← Home (catálogo)
├── styles.css                  ← CSS único compartido
├── sabores/
│   ├── frutilla.html           ← Fresi
│   ├── limon.html              ← Limé
│   ├── arandano.html           ← Aru
│   ├── vainilla.html           ← Vani
│   ├── maracuya.html           ← Maru
│   ├── coco.html               ← Coqui
│   └── pina.html               ← Pini
└── assets/
    ├── logo.svg                ← Logo ecomiga
    └── amiguitos/              ← 7 SVG de personajes
```

---

## 🚀 Cómo publicarlo

El sitio es 100% estático (HTML + CSS + SVG) — no necesita servidor ni build. Funciona en cualquier hosting gratuito:

### Opción 1: Netlify (recomendado, gratis)
1. Andá a [app.netlify.com/drop](https://app.netlify.com/drop)
2. Arrastrá la carpeta `ecomiga-site/` al cuadro
3. Listo — sale online en segundos con URL `xxx.netlify.app`

### Opción 2: Vercel (gratis)
1. Instalá Vercel CLI: `npm i -g vercel`
2. En la carpeta `ecomiga-site/`, ejecutá: `vercel`
3. Seguí los pasos

### Opción 3: Hosting tradicional
Subí la carpeta completa al servidor por FTP. `index.html` es la página de inicio.

### Probar local
Abrí `index.html` con doble click (funciona offline).

---

## 📱 WhatsApp

El número configurado es **+591 72133348** (Mirtha). Todos los botones de WhatsApp abren `wa.me/59172133348` con un mensaje pre-llenado según la página.

Para cambiarlo, editá la línea `WHATSAPP_NUMBER = "59172133348"` en `generate_site.py` y regenerá las páginas, o reemplazá manualmente en cada HTML.

---

## ✏️ Cambios futuros

El sitio se genera desde un script Python (`generate_site.py`). Para cambios:
- **Textos**: editá `AMIGUITOS` en el script (introducciones, taglines, etc.)
- **Diseño**: editá `styles.css` (todas las variables de color están al inicio)
- **Nuevos sabores**: agregá al diccionario `AMIGUITOS` y regenerá

Si preferís editar a mano, también podés modificar cada HTML directamente.

---

## 🎨 Sistema de diseño

- **Tipografía**: Fraunces (serif italic-heavy) + Plus Jakarta Sans (body)
- **Colores marca**: azul ecomiga `#0C348E` · aqua `#7AC9CB` · gold `#D0A03C`
- **Pastel por sabor**: cada amiguito tiene su tono propio en `:root`
- **Animaciones**: amiguitos flotantes en hero, wiggle en sabor, hover effects en cards

---

ecomiga · Mirtha Rivera · La Paz, Bolivia · 2026
